// A file is required to be in the root of the /src directory by the TypeScript compiler
