import {SPRest} from '@pnp/sp';
import "@pnp/sp/webs";
import "@pnp/sp/items/list";
import "@pnp/sp/lists";

export const sp= new SPRest();