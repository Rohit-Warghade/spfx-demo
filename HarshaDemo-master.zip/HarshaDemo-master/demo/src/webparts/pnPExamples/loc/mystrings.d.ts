declare interface IPnPExamplesWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'PnPExamplesWebPartStrings' {
  const strings: IPnPExamplesWebPartStrings;
  export = strings;
}
